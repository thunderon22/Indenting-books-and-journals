<?php 

  $con = mysqli_connect("localhost","root","","bank","3308");

  if(!$con){
    die("Connection Error");
  }

?>