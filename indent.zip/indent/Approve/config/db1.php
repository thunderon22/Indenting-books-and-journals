<?php 

  $con = mysqli_connect("localhost","root","","indenting","3308");

  if(!$con){
    die("Connection Error");
  }

?>